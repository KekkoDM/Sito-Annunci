package Associazioni;

public class Hotel extends Alloggio{
	private String Servizio;
	private int Stelle;
	
	public String getServizio() {
		return Servizio;
	}
	public void setServizio(String servizio) {
		Servizio = servizio;
	}
	public int getStelle() {
		return Stelle;
	}
	public void setStelle(int stelle) {
		Stelle = stelle;
	}
}
