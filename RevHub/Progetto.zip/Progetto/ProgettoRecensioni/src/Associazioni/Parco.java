package Associazioni;

public class Parco extends Attrazione{
	private int NGiostre;
	private boolean Zoo;
	private boolean Spettacoli;
	
	public int getNGiostre() {
		return NGiostre;
	}
	public void setNGiostre(int nGiostre) {
		NGiostre = nGiostre;
	}
	public boolean isZoo() {
		return Zoo;
	}
	public void setZoo(boolean zoo) {
		Zoo = zoo;
	}
	public boolean isSpettacoli() {
		return Spettacoli;
	}
	public void setSpettacoli(boolean spettacoli) {
		Spettacoli = spettacoli;
	}
	
	
}
