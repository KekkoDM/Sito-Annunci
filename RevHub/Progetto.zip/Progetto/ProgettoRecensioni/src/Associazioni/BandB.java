package Associazioni;

public class BandB extends Alloggio{
	private String CheckOut;
	private String CheckIn;
	private String Colazione;
	
	public String getCheckOut() {
		return CheckOut;
	}
	public void setCheckOut(String checkOut) {
		CheckOut = checkOut;
	}
	public String getCheckIn() {
		return CheckIn;
	}
	public void setCheckIn(String checkIn) {
		CheckIn = checkIn;
	}
	public String getColazione() {
		return Colazione;
	}
	public void setColazione(String colazione) {
		Colazione = colazione;
	}
	
	
}
