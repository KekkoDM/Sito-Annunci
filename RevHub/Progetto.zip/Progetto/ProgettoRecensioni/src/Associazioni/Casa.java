package Associazioni;

public class Casa extends Alloggio{
	private String Giardino;
	private String Location;
	
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getGiardino() {
		return Giardino;
	}
	public void setGiardino(String giardino) {
		Giardino = giardino;
	}
	
}
