package Associazioni;

public class Mare extends ristorante{
	private String TipoM;

	public String getTipoM() {
		return TipoM;
	}

	public void setTipoM(String tipoM) {
		TipoM = tipoM;
	}
	
}
