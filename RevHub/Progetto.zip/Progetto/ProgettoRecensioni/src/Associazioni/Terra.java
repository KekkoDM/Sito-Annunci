package Associazioni;

public class Terra extends ristorante {

}
