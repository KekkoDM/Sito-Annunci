package Associazioni;

public class ristorante {
	
	private String Nome;
	private String Citt�;
	private String Via;
	private int Civico;
	private String Telefono;
	private int codri;
	private String specialita;
	private String provenienza;
	private String qualita;
	private String tipo;
	private int codt;
	private int codm;
	private int codv;
	
	public int getCodri() {
		return codri;
	}
	public void setCodri(int codri) {
		this.codri = codri;
	}
	
	public String getSpecialita() {
		return specialita;
	}
	public void setSpecialita(String specialita) {
		this.specialita = specialita;
	}
	
	
	public String getProvenienza() {
		return provenienza;
	}
	public void setProvenienza(String provenienza) {
		this.provenienza = provenienza;
	}
	
	
	public String getQualita() {
		return qualita;
	}
	public void setQualita(String qualita) {
		this.qualita = qualita;
	}
	
	
	public int getCodt2() {
		return codt;
	}
	public void setCodt2(int codt2) {
		this.codt = codt2;
	}
	
	
	public int getCodm2() {
		return codm;
	}
	public void setCodm2(int codm2) {
		this.codm = codm2;
	}
	
	
	public int getCodv2() {
		return codv;
	}
	public void setCodv2(int codv2) {
		this.codv = codv2;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getCitt�() {
		return Citt�;
	}
	public void setCitt�(String citt�) {
		Citt� = citt�;
	}
	public String getVia() {
		return Via;
	}
	public void setVia(String via) {
		Via = via;
	}
	public int getCivico() {
		return Civico;
	}
	public void setCivico(int i) {
		Civico = i;
	}
	public String getTelefono() {
		return Telefono;
	}
	public void setTelefono(String telefono) {
		Telefono = telefono;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String t) {
		tipo = t;
	}
	

}
