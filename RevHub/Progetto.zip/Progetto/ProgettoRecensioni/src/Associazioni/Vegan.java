package Associazioni;

public class Vegan extends ristorante {
	private String TipoV;

	public String getTipoV() {
		return TipoV;
	}

	public void setTipoV(String tipoV) {
		TipoV = tipoV;
	}
}
