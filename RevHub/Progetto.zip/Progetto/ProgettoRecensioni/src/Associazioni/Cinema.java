package Associazioni;

public class Cinema extends Attrazione {
	private int NSale;
	private int Capienza;
	
	public int getNSale() {
		return NSale;
	}
	public void setNSale(int nSale) {
		NSale = nSale;
	}
	public int getCapienza() {
		return Capienza;
	}
	public void setCapienza(int capienza) {
		Capienza = capienza;
	}
	
	
}
